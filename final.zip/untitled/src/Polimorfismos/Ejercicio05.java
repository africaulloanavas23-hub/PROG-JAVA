package Polimorfismos;
interface Cantante{
    void cantar();
}
interface Bailarin{
    void bailar();
}
class Artista implements Cantante, Bailarin{
    public void cantar(){
        System.out.println("El artista canta");
    }
    public void bailar(){
        System.out.println("El artista baila");
    }
}

public class Ejercicio05 {
    public static void main(String[] args){
        Cantante c = new Artista();
        Bailarin b = new Artista();
        c.cantar();
        b.bailar();
    }
}
