package Polimorfismos;
interface Volador{
    void volar();
}
class Pajaro implements Volador{
   public  void volar(){
        System.out.println("El pajaro vuela");
    }
}
class Avion implements Volador {
    public void volar(){
        System.out.println("El avion vuela");
    }
}

public class Ejercicio03 {
    public static void main(String[] args){
        Volador v1= new Pajaro();
        Volador v2= new Avion();
        v1.volar();
        v2.volar();



    }
}