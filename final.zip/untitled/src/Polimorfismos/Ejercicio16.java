package Polimorfismos;
import java.util.Scanner;
public class Ejercicio16 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Primera calificación: ");
        double nota1 = sc.nextDouble();
        System.out.println("Segunda calificación: ");
        double nota2 = sc.nextDouble();
        System.out.println("Tercera calificación: ");
        double nota3 = sc.nextDouble();
        System.out.println("Calificación 1: " + nota1);
        System.out.println("Calificación 2: " + nota2);
        System.out.println("Calificación 3: " + nota3);
        double media = (nota1 + nota2 + nota3)/3;
        System.out.printf("Promedio: %.2f\n" , media);
        if (media >= 9){
            System.out.println("Sobresaliente");
        } else if (media >= 7){
            System.out.println("Notable");
        } else if (media >= 5){
            System.out.println("Aprobado");
        } else {
            System.out.println("Suspenso");
        }

    }

}
