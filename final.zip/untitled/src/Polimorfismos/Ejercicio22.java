
import java.util.Scanner;
public class Ejercicio22 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce tu nota");
        double nota = sc.nextDouble();
        if (nota >= 5) {
            System.out.println("¡Enhorabuena! Has aprobado");
        } else {
            System.out.println("Has suspendido");
        }
        sc.close();
    }

}
