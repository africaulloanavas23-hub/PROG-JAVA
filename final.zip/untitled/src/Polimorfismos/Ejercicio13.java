package Polimorfismos;
import java.util.Scanner;
public class Ejercicio13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el primer número: ");
        int a = sc.nextInt();
        System.out.println("Introduce el segundo número: ");
        int b = sc.nextInt();
        System.out.println("Introduce el tercer número: ");
        int c = sc.nextInt();
        int mayor = a;
        int menor = a;
        if (b > mayor) {
            mayor = b;
        }
        if (c > mayor) {
            mayor = c;
        }
        if (c < menor) {
            menor = c;
        }

        if (b < menor) {
            menor = b;
        }
        System.out.println("El número mayor es: " + mayor);
        System.out.println("El número menor es: " + menor);
    }}

