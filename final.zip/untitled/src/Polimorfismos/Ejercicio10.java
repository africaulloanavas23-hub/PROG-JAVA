package Polimorfismos;
import java.util.Scanner;

public class Ejercicio10 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un número ");
        int num = sc.nextInt();
        System.out.println("Número original: "+ num);
        int suma= num+10;
        System.out.println("Después de sumar 10: "+suma);
        int multiplicar = suma*2;
        System.out.println("Después de multiplicar por 2: "+multiplicar);
        int restar = multiplicar-5;
        System.out.println("Después de restas 5: "+ restar);
        int dividir = restar/3;
        System.out.println("Después de dividir entre 3: "+ dividir);
    }

}
