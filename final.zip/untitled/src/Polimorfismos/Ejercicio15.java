package Polimorfismos;
import java.util.Scanner;
public class Ejercicio15 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce tu edad: ");
        int edad = sc.nextInt();
        System.out.println("¿Eres estudiante? (true/false)");
        boolean estudiante = sc.nextBoolean();
        System.out.println("Edad: " + edad);
        System.out.println("Estudiante: " + estudiante);
        boolean cumpleEdad= edad<25;
        boolean cumpleEstudiante = estudiante;

        boolean tieneDescuento = cumpleEdad && cumpleEstudiante;

        System.out.println("¿Tiene descuento?: " + tieneDescuento);
        System.out.println("Cumple el requisito edad: " + cumpleEdad);
        System.out.println("Cumple el requisito estudiante: " + cumpleEstudiante);
    }
}
