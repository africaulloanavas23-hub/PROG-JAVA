package Polimorfismos;

import java.io.PrintStream;
import java.util.Scanner;

public class Ejercicio17 {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce la puntación inicial: ");
        double puntos = sc.nextDouble();
        System.out.println("Puntuación inicial: " + puntos);
        puntos += 50;
        System.out.println("Después de sumar 50 puntos (+=): " + puntos);
        puntos -= 20;
        System.out.println("Después de restar 20 puntos (-=): " + puntos);
        puntos *= 2;
        System.out.println("Después de multiplicar por 2 (*=): " + puntos);
        puntos /= 3;
       System.out.printf("Después de dividir entre 3 (/=): %.2f\n" , puntos);


    }
}
