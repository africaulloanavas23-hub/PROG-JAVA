package Polimorfismos;
interface Dispositivo {
    void encender();
}
class Televisor implements Dispositivo{
    public void encender(){
        System.out.println(" El televisor se enciende");
    }
}
class Radio implements Dispositivo {
    public void encender() {
        System.out.println("La radio se enciende");
    }
}
public class Ejercicio06 {
    public static void main(String[] args){
        Dispositivo[] d = new Dispositivo[3];
        d[0]= new Televisor();
        d[1]= new Radio();
        d[2]= new Televisor();
        for (int i =0; i< d.length; i++){
            d[i].encender();
        }
    }
}
