package Polimorfismos;

public class Ejercicio14 {
    public static void main(String[] args){
        int a = 5 ;
        int b = 2;
        int c = 9;
        int mayor = a;
        int menor = a;
        if (a == b && b == c) {
            System.out.println("Todos son iguales: " + a);
        } else if (a == b) {
            System.out.println("Se repite el numero: " + a);
        } else if (a == c) {
            System.out.println("Se repite el numero: " + a);
        } else if (b == c) {
            System.out.println("Se repite el numero: " + b);
        } else {
            System.out.println("Todos son diferentes");
        }


        if (b>mayor){
            mayor = b;
        }
        if (c>mayor){
            mayor = c ;
        }
        if (b<menor){
            menor = b;
        }
        if (c<menor){
            menor= c;
        }

        int medio = a + b + c - mayor - menor;

        System.out.println("Salida; " + mayor+ ", " + medio + ", " + menor);

    }
}