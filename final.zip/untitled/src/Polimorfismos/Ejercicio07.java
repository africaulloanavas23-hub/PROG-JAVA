package Polimorfismos;
class Animal{
    public void sonido(){
        System.out.println("El animal hace un sonidio ");
    }
}
class Perro extends Animal{
   public void sonido(){
       System.out.println("El perro hace sonido");
   }
}
public class Ejercicio07 {
    public static void main(String[] args){
        Animal a1 = new Animal();
        Animal a2 = new Perro();
        a1.sonido();
        a2.sonido();


    }
}
