package Polimorfismos;
import java.util.Scanner;
public class Ejercicio19 {
    public static void main (String[] args){
    Scanner sc = new Scanner(System.in);
    System.out.println("Introduce el nombre del producto: ");
            String nombre = sc.nextLine();
    System.out.println("Introduce el precio base: ");
     double precio = sc.nextDouble();
     System.out.println("Introduce la cantidad en stock: ");
     int stock = sc.nextInt();
     System.out.println("¿Está en promoción? (true/false): ");
     boolean prom = sc.nextBoolean();


     System.out.println("------INFORMACIÓN DEL PRODUCTO-----");

     System.out.println("Nombre: " + nombre);
     System.out.println("Precio base: " + precio + "$");
     System.out.println("Cantidad en stock: " + stock);
     System.out.println("En promoción: " + prom);


     System.out.println("--------CÁLCULOS------");

     double precioTotal = precio*stock;
     System.out.println("Precio total sin descuento: " + precioTotal + "$");
     System.out.println("¿Aplica descuento?: " + prom);

     if (prom ) {
         double descuentoTotal = precioTotal * 20 / 100;
         System.out.println("Descuento aplicado: " + descuentoTotal);
         double precioFinal = precioTotal - descuentoTotal;
         System.out.println("Precio total con descuento: " + precioFinal);
     }else {
         System.out.println("Sin descuento");
     }


     System.out.println("-------ANÁLISIS DE STOCK------");
     boolean stockBajo = stock < 10 ;
     boolean stockMedio = stock >=10 && stock <=50;
     boolean stockAlto = stock>=50;
     System.out.println("¿stock bajo? (menor a 10): " + stockBajo);
     System.out.println("¿Stock medio? (entre 10 y 50): " + stockMedio);
     System.out.println("¿Stock alto? (mayor a 50): " + stockAlto);
     String estado;
     if (stockAlto){
         estado = "ALTO";
     }else if (stockMedio){
         estado = "MEDIO";
     }else{
         estado ="BAJO";
     }
     System.out.println("Estado del stock: " + estado);

     }




}
