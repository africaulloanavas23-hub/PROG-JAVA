package Polimorfismos;
import java.util.Scanner;
public class Ejercicio09 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce el primer numero ");
        int num1 = sc.nextInt();

        System.out.println("Introduce el segundo numero");
        int num2 = sc.nextInt();

        if (num1>num2){
            System.out.println("El segundo numero ("+ num2 + ") es menor que el primer numero (" + num1+ ")");
        System.out.println("Los números son diferentes");
        } else if (num1<num2){
            System.out.println("El primer numero (" + num1 + ") es menor que el segundo número ("+num2+ ")");
            System.out.println("Los números son diferentes");
        }else {
            System.out.println("Los números son iguales");
        }
    }
}
