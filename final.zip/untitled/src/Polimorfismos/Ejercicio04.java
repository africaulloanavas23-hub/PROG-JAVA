
interface Animal {
    void hacerSonido();
}
class Perro implements Animal{
    public void hacerSonido(){
        System.out.println("El perro ladra");
    }
}
class Gato implements Animal{
    public void hacerSonido(){
        System.out.println("El gato maulla ");
    }
}
public class Ejercicio04 {
    public static void main(String[] args){
        Animal[] animal = new  Animal[2];
        animal[0] = new Perro();
        animal[1]= new Gato();
    for(int i = 0 ; i<animal.length ; i++){
        animal[i].hacerSonido();
    }
    }
}
