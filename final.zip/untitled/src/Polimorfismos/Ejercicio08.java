package Polimorfismos;
class Trabajador{
    String nombre;

    public void trabajar(){
        System.out.println("El trabajador trabaja");
    }
}
class Jefe extends Trabajador{
    public void trabajar(){
        System.out.println("El jefe dirige");
    }
}

public class Ejercicio08 {
    public static void main(String[] args){
        Trabajador t1 = new Trabajador();
        Jefe j1 = new Jefe();
        t1.trabajar();
        j1.trabajar();
    }
}
