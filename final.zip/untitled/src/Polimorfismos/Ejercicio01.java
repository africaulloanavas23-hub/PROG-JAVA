package Polimorfismos;
interface Vehiculo {
    void arrancar();
}
class Coche implements Vehiculo{
    public void arrancar(){
        System.out.println("El coche arranca");
    }
}
class Moto implements Vehiculo{
    public void arrancar(){
        System.out.println("La moto arranca");

    }
}


public class Ejercicio01 {
    public static void main(String[] args ){
        Vehiculo[] vehiculo = new Vehiculo[2];
        vehiculo[0]= new Coche();
        vehiculo[1]= new Moto();
        for(int i = 0; i<vehiculo.length;i++){
            vehiculo[i].arrancar();
        }
    }
}
