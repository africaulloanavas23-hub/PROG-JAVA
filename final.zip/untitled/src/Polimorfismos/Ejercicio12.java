package Polimorfismos;
import java.util.Scanner;
public class Ejercicio12 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero: ");
        int num = sc.nextInt();
        int resto= num%2;
        if(resto == 0){
            System.out.println("El número " +num+ " es par");
        }else{
            System.out.println("El número " +num+ " es impar");
        }
            System.out.println("El resto de dividir "+num+ " entre 2 es: "+resto);

    }
}
