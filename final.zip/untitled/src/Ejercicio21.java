import java.util.Scanner;
public class Ejercicio21 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un número: ");
        int num = sc.nextInt();
        if(num>0){
            System.out.println("El número es positivo");

        }else if (num==0){
            System.out.println("El número es igual a 0");
        }else {
            System.out.println("El número es negativo");
        }
        sc.close();
    }
}
