import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({TemperaturaTest.class, MonedaTest.class})
public class SuiteFinalTest {
}