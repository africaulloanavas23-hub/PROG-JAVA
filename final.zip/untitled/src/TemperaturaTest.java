import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TemperaturaTest {

    @Test
    void testTemperatura() {
        Temperatura t = new Temperatura();

        // Fahrenheit
        assertEquals(-40, t.Fahrenheittocelsius(-40));
        assertEquals(0, t.Fahrenheittocelsius(32));

        // Celsius
        assertEquals(23, t.celsiustofahrenheit(-5));
        assertEquals(59, t.celsiustofahrenheit(15));
    }
}