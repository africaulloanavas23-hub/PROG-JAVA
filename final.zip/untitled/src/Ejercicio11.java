import java.util.Scanner;
public class Ejercicio11 {

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el precio del producto: ");
        int precio = sc.nextInt();
        System.out.println("Introduce el porcentaje de descuento: ");
        int porcentaje = sc.nextInt();
        System.out.println("Precio original: "+ precio+ "$");
        System.out.println("Descuento aplicado: " +porcentaje+ "%");
        int descuento = precio*porcentaje/100;
        int descuento2= precio-descuento;
        System.out.println("Cantidad descontada: " + descuento+ "$");
        System.out.println("Precio final: " +descuento2+ "$");



    }
}
