public class Calculadora {

    public int multiplica(int a, int b) {
        return a * b;
    }

    public int factorial(int n) {
        int resultado = 1;
        for (int i = 1; i <= n; i++) {
            resultado *= i;
        }
        return resultado;
    }
}