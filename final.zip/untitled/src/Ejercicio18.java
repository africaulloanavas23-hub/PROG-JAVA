import java.util.Scanner;

public class Ejercicio18 {
    public static void main(String[] args){

        Scanner sc  = new Scanner(System.in);

        System.out.print("Introduce un número: ");
        int num = sc.nextInt();

        boolean entre10y50 = num >= 10 && num <= 50;
        boolean es100 = num == 100;
        boolean cumple = entre10y50 || es100;

        System.out.println("Número introducido: " + num);
        System.out.println("¿Está entre 10 y 50?: " + entre10y50);
        System.out.println("¿Es exactamente 100?: " + es100);
        System.out.println("¿Cumple alguna condición?: " + cumple);
        System.out.println("¿Es mayor o igual a 10?: " + (num >= 10));
        System.out.println("¿Es menor o igual a 50?: " + (num <= 50));

        sc.close();
    }
}