import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MonedaTest {

    @Test
    void testMoneda() {
        Moneda m = new Moneda();

        assertEquals(8.925, m.dolarEuro(10.5),0.01);
        assertEquals(23.88, m.euroDolar(20.3), 0.01);
    }
}