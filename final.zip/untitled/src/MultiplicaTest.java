import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MultiplicaTest {

    @Test
    void testMultiplica() {
        Calculadora c = new Calculadora();
        assertEquals(6, c.multiplica(2, 3));
    }
}