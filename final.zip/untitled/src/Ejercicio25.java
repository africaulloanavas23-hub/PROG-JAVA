import java.util.Scanner;

public class Ejercicio25 {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce tu nota: ");
        int nota = sc.nextInt();

        if (nota >= 0 && nota <= 4) {
            System.out.println("Suspenso");
        } else if (nota <= 6) {
            System.out.println("Aprobado");
        } else if (nota <= 8) {
            System.out.println("Notable");
        } else if (nota <= 10) {
            System.out.println("Sobresaliente");
        } else {
            System.out.println("Nota no válida");
        }

        sc.close();
    }
}