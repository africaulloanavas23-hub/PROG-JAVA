import java.util.Scanner;
public class Ejercicio20 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce tu edad: ");
        int edad = sc.nextInt();
        if(edad>=18){
            System.out.println("Eres mayor de edad.Puedes votar.");
        }else{
            System.out.println("Eres menor de edad. No puedes votar.");
        }
        sc.close();
    }
}
