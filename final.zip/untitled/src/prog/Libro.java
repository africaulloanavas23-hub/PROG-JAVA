package prog;
import java.io.Serializable;

public abstract class Libro implements Serializable {
    protected String autor;
    protected int numeroPaginas;
    protected String ISBN;

    public Libro(String autor, int numeroPaginas, String ISBN) {
        this.autor = autor;
        this.numeroPaginas = numeroPaginas;
        this.ISBN = ISBN;
    }

    public String getISBN() {
        return ISBN;
    }

    @Override
    public String toString() {
        return "Autor: " + autor + ", Paginas: " + numeroPaginas + ", ISBN: " + ISBN;
    }
}