package prog;
public class Biblioteca {
    private String nombre;
    private String director;
    private Catalogo catalogo;

    public Biblioteca(String nombre, String director) {
        this.nombre = nombre;
        this.director = director;
    }

    public void crearCatalogo(int capacidad) {
        catalogo = new Catalogo(capacidad);
    }

    public Catalogo getCatalogo() {
        return catalogo;
    }
}