package prog;
public class LibroTerror extends Libro {
    private int calificacion;

    public LibroTerror(String autor, int numeroPaginas, String ISBN, int calificacion) {
        super(autor, numeroPaginas, ISBN);
        this.calificacion = calificacion;
    }

    @Override
    public String toString() {
        return super.toString() + ", Calificacion: " + calificacion;
    }
}