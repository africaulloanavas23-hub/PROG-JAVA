package prog;
public class LibroPoliciaca extends Libro {
    private String trama;
    private String personaje;

    public LibroPoliciaca(String autor, int numeroPaginas, String ISBN, String trama, String personaje) {
        super(autor, numeroPaginas, ISBN);
        this.trama = trama;
        this.personaje = personaje;
    }

    @Override
    public String toString() {
        return super.toString() + ", Trama: " + trama + ", Personaje: " + personaje;
    }
}