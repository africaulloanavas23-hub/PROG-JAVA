package prog;
import java.io.*;
import java.util.ArrayList;

public class Catalogo implements Serializable {
    private ArrayList<Libro> libros;
    private int capacidad;

    public Catalogo(int capacidad) {
        this.capacidad = capacidad;
        this.libros = new ArrayList<>();
    }

    public void agregarLibro(Libro libro) throws CatalogoLlenoException {
        if (libros.size() >= capacidad) {
            throw new CatalogoLlenoException("No hay espacio en el catálogo");
        }

        for (Libro l : libros) {
            if (l.getISBN().equals(libro.getISBN())) {
                System.out.println("El libro ya existe");
                return;
            }
        }

        libros.add(libro);
    }

    public void eliminarLibro(String isbn) throws LibroNoEncontradoException {
        Libro encontrado = null;

        for (Libro l : libros) {
            if (l.getISBN().equals(isbn)) {
                encontrado = l;
                break;
            }
        }

        if (encontrado == null) {
            throw new LibroNoEncontradoException("Libro no encontrado");
        }

        libros.remove(encontrado);
    }

    public Libro buscarLibro(String isbn) throws LibroNoEncontradoException {
        for (Libro l : libros) {
            if (l.getISBN().equals(isbn)) {
                return l;
            }
        }
        throw new LibroNoEncontradoException("Libro no encontrado");
    }

    public void mostrarLibros() {
        for (Libro l : libros) {
            System.out.println(l);
        }
    }
    public void guardarEnFichero() {
        try {
            String ruta = System.getProperty("user.home") + "/Desktop/libros.obj";
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta));
            oos.writeObject(libros);
            oos.close();
            System.out.println("Guardado en: " + ruta);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}