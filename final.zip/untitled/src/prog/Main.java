package prog;
public class Main {
    public static void main(String[] args) {

        Biblioteca biblioteca = new Biblioteca("Mi Biblioteca", "Juan");
        biblioteca.crearCatalogo(4);

        Catalogo catalogo = biblioteca.getCatalogo();

        try {
            catalogo.agregarLibro(new LibroTerror("Autor1", 200, "1", 8));
            catalogo.agregarLibro(new LibroComedia("Autor2", 150, "2", "ironico"));
            catalogo.agregarLibro(new LibroPoliciaca("Autor3", 300, "3", "misterio", "detective"));
            catalogo.agregarLibro(new LibroTerror("Autor4", 250, "4", 9));

            // ESTE DEBE FALLAR (5º libro)
            catalogo.agregarLibro(new LibroComedia("Autor5", 100, "5", "absurdo"));

        } catch (CatalogoLlenoException e) {
            System.out.println(e.getMessage());
        }

        catalogo.mostrarLibros();

        catalogo.guardarEnFichero();
    }
}