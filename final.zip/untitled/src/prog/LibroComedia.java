package prog;
public class LibroComedia extends Libro {
    private String tipoHumor;

    public LibroComedia(String autor, int numeroPaginas, String ISBN, String tipoHumor) {
        super(autor, numeroPaginas, ISBN);
        this.tipoHumor = tipoHumor;
    }

    @Override
    public String toString() {
        return super.toString() + ", Humor: " + tipoHumor;
    }
}