import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class FactorialTest {

    @Test
    void testFactorial() {
        Calculadora c = new Calculadora();
        assertEquals(120, c.factorial(5));
    }
}