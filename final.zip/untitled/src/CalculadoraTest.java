import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class CalculadoraTest {

    @Test
    void testMultiplica() {
        Calculadora c = new Calculadora();
        assertEquals(5, c.multiplica(2, 3));
    }

    @Test
    void testFactorial() {
        Calculadora c = new Calculadora();
        assertEquals(120, c.factorial(5));
    }
}