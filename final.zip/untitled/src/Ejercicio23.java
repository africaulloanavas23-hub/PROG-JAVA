import java.util.Scanner;

public class Ejercicio23 {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce el importe de la compra: ");
        double importe = sc.nextDouble();

        double descuento = 0;
        double importeFinal;

        if (importe >= 100) {
            descuento = importe * 0.10;
        }

        importeFinal = importe - descuento;

        System.out.println("Importe original: " + importe + "€");
        System.out.println("Descuento aplicado: " + descuento + "€");
        System.out.println("Importe final: " + importeFinal + "€");

        sc.close();
    }
}