public class Temperatura {

    public double Fahrenheittocelsius(double f) {
        return (f - 32) * 5 / 9;
    }

    public double celsiustofahrenheit(double c) {
        return (c * 9 / 5) + 32;
    }
}