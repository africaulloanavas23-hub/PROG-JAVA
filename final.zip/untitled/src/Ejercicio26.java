interface Trabajador {
    void trabajar();
}
abstract class Persona{
    public abstract void saludar();
}
class Programador extends Persona implements Trabajador{
    public void trabajar(){
        System.out.println("Trabajo");
    }
    public void saludar(){
        System.out.println("Hola");
    }

}

public class Ejercicio26 {
    public static void main (String[] args){
        Persona p = new Programador();
        p.saludar();
        ((Programador)p).trabajar();
    }
}
